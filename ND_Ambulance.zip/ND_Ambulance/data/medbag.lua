return { -- items included in a medbag, item. Name and amount.
    {"tourniquet", 4},
    {"gauze", 15},
    {"burndressing", 15},
    {"splint", 3},
    {"bandage", 5}
}
