-- this is groups that can check other player injuries while that player is alive.
return {"lsfd"}
