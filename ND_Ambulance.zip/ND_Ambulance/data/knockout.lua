return { -- these weapons will knockout the player instead of injuring them like a regular weapon.
    `weapon_bat`,
    `weapon_unarmed`,
    `weapon_golfclub`,
    `weapon_hammer`,
    `weapon_knuckle`,
    `weapon_nightstick`,
    `weapon_wrench`,
    `weapon_poolcue`,
    `weapon_candycane`,
    `weapon_snowball`
}
