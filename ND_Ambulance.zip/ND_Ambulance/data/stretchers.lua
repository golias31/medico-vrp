-- stretcher models in strings, make sure the stretcher model has a lowered version named loweredstretchername, for example loweredfernocot. Don't write the lowered model in here.
return {"fernocot", "strykergurney"}
