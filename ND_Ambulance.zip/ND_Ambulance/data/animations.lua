return {
    -- {
    --     knocked = {"random@dealgonewrong", "idle_a"},
    --     eliminated = {"random@crash_rescue@dead_ped", "dead_ped"}, -- weird
    --     vehicle = {"random@crash_rescue@car_death@van", "loop"}
    -- },
    -- {
    --     knocked = {"anim@scripted@data_leak@fix_bil_ig2_chopper_crawl@prototype@", "injured_idle_ped"},
    --     eliminated = {"missfinale_c1@", "lying_dead_player0"},
    --     vehicle = {"random@crash_rescue@car_death@van", "loop"}
    -- },
    {
        knocked = {"anim@scripted@data_leak@fix_bil_ig2_chopper_crawl@prototype@", "injured_idle_ped"},
        eliminated = {"misssolomon_5@end", "dead_black_ops"},
        vehicle = {"random@crash_rescue@car_death@van", "loop"}
    }
}
